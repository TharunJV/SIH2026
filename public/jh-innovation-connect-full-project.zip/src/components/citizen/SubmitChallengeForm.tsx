import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ChallengeCategory, ChallengeUrgency } from '../../types';
import { JHARKHAND_DISTRICTS, CATEGORIES_LIST } from '../../mock/data';
import { challengeService } from '../../services/challengeService';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  MapPin,
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Camera,
  Video,
  ShieldCheck,
  ArrowRight,
  ChevronRight,
  Eye,
  Info,
  Clock,
} from 'lucide-react';

export const SubmitChallengeForm: React.FC = () => {
  const { currentUser, showToast, refreshData, navigateToChallenge, setCurrentView } = useApp();

  const [step, setStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedChallengeId, setSubmittedChallengeId] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ChallengeCategory>('Water Resources');
  const [subCategory, setSubCategory] = useState('');
  const [district, setDistrict] = useState<string>('Khunti');
  const [block, setBlock] = useState('Torpa');
  const [village, setVillage] = useState('Dormo Panchayat');
  const [gps, setGps] = useState({ lat: 22.9567, lng: 85.0844 });
  const [affectedPopulation, setAffectedPopulation] = useState<number>(12500);
  const [frequency, setFrequency] = useState<'Daily' | 'Seasonal' | 'Recurring Periodic' | 'One-Time Event'>('Daily');
  const [urgency, setUrgency] = useState<ChallengeUrgency>('High');
  const [expectedImpact, setExpectedImpact] = useState('');
  const [additionalInformation, setAdditionalInformation] = useState('');
  const [consentAccepted, setConsentAccepted] = useState(true);

  // Mock Evidence Uploads
  const [evidenceList, setEvidenceList] = useState<
    { type: 'image' | 'video' | 'document' | 'audio'; url: string; caption: string }[]
  >([
    {
      type: 'image',
      url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?w=600&auto=format&fit=crop&q=80',
      caption: 'Groundwater pump crusting and turbidity',
    },
  ]);
  const [newCaption, setNewCaption] = useState('');

  const handleAutoGPS = () => {
    // Simulate high precision GPS lock in Jharkhand
    setGps({
      lat: Number((22.8 + Math.random() * 1.5).toFixed(4)),
      lng: Number((84.5 + Math.random() * 2.5).toFixed(4)),
    });
    showToast('info', 'GPS Coordinate Locked', `Geotagged location at ${gps.lat}° N, ${gps.lng}° E`);
  };

  const handleAddSampleEvidence = () => {
    setEvidenceList((prev) => [
      ...prev,
      {
        type: 'image',
        url: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=600&auto=format&fit=crop&q=80',
        caption: newCaption || 'Village community field evidence',
      },
    ]);
    setNewCaption('');
    showToast('success', 'Evidence Attached', 'Photo evidence uploaded to prototype storage bucket.');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !expectedImpact) {
      showToast('warning', 'Missing Details', 'Please fill in all mandatory problem fields.');
      return;
    }

    if (!consentAccepted) {
      showToast('warning', 'Consent Required', 'Please confirm that problem details are accurate.');
      return;
    }

    setIsSubmitting(true);
    try {
      const newCh = await challengeService.createChallenge({
        title,
        description,
        category,
        subCategory: subCategory || undefined,
        district,
        block,
        village,
        gpsCoordinates: gps,
        affectedPopulation,
        frequency,
        urgency,
        expectedImpact,
        additionalInformation,
        submittedBy: {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          contactNumber: currentUser.phone || '+91 98351 00000',
          organization: currentUser.organization,
        },
        evidenceUrls: evidenceList,
      });

      await refreshData();
      setSubmittedChallengeId(newCh.id);

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (err) {
        // Ignore in environments without canvas
      }

      showToast('success', 'Challenge Registered', `Generated ID: ${newCh.id}. AI analysis pipeline executed!`);
    } catch (err) {
      showToast('error', 'Submission Error', 'Failed to register challenge.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // If submitted, show success state
  if (submittedChallengeId) {
    return (
      <div className="max-w-3xl mx-auto my-6 bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-2xl text-center space-y-6 animate-in zoom-in-95 duration-200">
        <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto ring-8 ring-emerald-50">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 uppercase tracking-wider">
            Challenge Submitted Successfully
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Problem Registered in Jharkhand State Portal
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto leading-relaxed">
            Your community challenge has been logged into the Department of Higher & Technical Education repository.
          </p>
        </div>

        {/* Challenge ID Box */}
        <div className="p-5 rounded-2xl bg-slate-900 text-white max-w-md mx-auto border border-slate-800 shadow-inner">
          <span className="text-[11px] text-slate-400 uppercase tracking-widest block font-bold">
            Unique Challenge Tracking ID
          </span>
          <div className="text-2xl font-black text-amber-400 tracking-wider my-1 font-mono">
            {submittedChallengeId}
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> State Verification & AI Triage Initialized
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left max-w-lg mx-auto text-xs text-slate-600">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block">District & Block</span>
            <span>{district} &bull; {block}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block">Affected People</span>
            <span>{(affectedPopulation || 0).toLocaleString()} citizens</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="font-bold text-slate-900 block">Urgency</span>
            <span className="font-bold text-amber-800">{urgency}</span>
          </div>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => navigateToChallenge(submittedChallengeId)}
            className="w-full sm:w-auto px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>View AI Analysis & University Matching &rarr;</span>
          </button>
          <button
            onClick={() => {
              setSubmittedChallengeId(null);
              setTitle('');
              setDescription('');
              setStep(1);
            }}
            className="w-full sm:w-auto px-5 py-3 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-all"
          >
            Submit Another Challenge
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
              Citizen & Community Crowdsourcing
            </span>
            <span className="text-xs text-slate-400">Step {step} of 3</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-1">
            Submit a Community Challenge
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Empower Jharkhand HEIs (BIT Mesra, IIT ISM, NIT) and Industry to engineer a deployable solution.
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-800 p-1.5 rounded-xl border border-slate-700 text-xs">
          <button
            onClick={() => setStep(1)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              step === 1 ? 'bg-emerald-700 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            1. Problem
          </button>
          <button
            onClick={() => setStep(2)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              step === 2 ? 'bg-emerald-700 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            2. Location & Impact
          </button>
          <button
            onClick={() => setStep(3)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              step === 3 ? 'bg-emerald-700 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            3. Evidence & Submit
          </button>
        </div>
      </div>

      {/* Form Wizard */}
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        {step === 1 && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                Challenge Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g., High Fluoride Contamination in Handpumps of Torpa Block"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-xs sm:text-sm p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Provide a clear, specific headline stating the core societal or infrastructure obstacle.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Primary Domain / Category <span className="text-rose-500">*</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ChallengeCategory)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 font-semibold focus:ring-2 focus:ring-emerald-500"
                >
                  {CATEGORIES_LIST.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Sub-Category / Technical Focus
                </label>
                <input
                  type="text"
                  placeholder="e.g. Groundwater Purification & IoT Telemetry"
                  value={subCategory}
                  onChange={(e) => setSubCategory(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                Comprehensive Problem Description <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={5}
                required
                placeholder="Describe what is happening, what causes the issue, who is suffering, seasonal variations, and past failed remedies..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 leading-relaxed"
              ></textarea>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => {
                  if (!title || !description) {
                    showToast('warning', 'Required Fields', 'Please enter title and description.');
                    return;
                  }
                  setStep(2);
                }}
                className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                <span>Proceed to Location & Impact</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5 animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  District <span className="text-rose-500">*</span>
                </label>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 font-semibold focus:ring-2 focus:ring-emerald-500"
                >
                  {JHARKHAND_DISTRICTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Block / Tehsil <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Torpa / Bishunpur / Katras"
                  value={block}
                  onChange={(e) => setBlock(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Village / Ward / Locality <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dormo & Jamhar Tolas"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* GPS Geotagging Box */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-900 block">GPS Coordinates (Geotagged)</span>
                  <span className="text-[11px] text-slate-600 font-mono">
                    Lat: {gps.lat.toFixed(4)}° N, Lng: {gps.lng.toFixed(4)}° E &bull; Accuracy: ±3m
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={handleAutoGPS}
                className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-100 shadow-2xs"
              >
                Refresh Device GPS
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Estimated Affected Population
                </label>
                <input
                  type="number"
                  min={10}
                  value={affectedPopulation}
                  onChange={(e) => setAffectedPopulation(Number(e.target.value))}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Frequency of Problem
                </label>
                <select
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value as any)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Daily">Daily / Constant</option>
                  <option value="Seasonal">Seasonal (Monsoon / Summer)</option>
                  <option value="Recurring Periodic">Recurring Periodic</option>
                  <option value="One-Time Event">One-Time Event</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Urgency Level <span className="text-rose-500">*</span>
                </label>
                <select
                  value={urgency}
                  onChange={(e) => setUrgency(e.target.value as ChallengeUrgency)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 font-bold focus:ring-2 focus:ring-emerald-500 text-amber-900"
                >
                  <option value="Critical">Critical (Immediate Health/Life Risk)</option>
                  <option value="High">High (Severe Economic/Livelihood Loss)</option>
                  <option value="Medium">Medium (Regular Inconvenience)</option>
                  <option value="Low">Low (General Quality of Life)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                Expected Societal Impact of Solution <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={3}
                required
                placeholder="What tangible benefits will happen when solved? e.g. Eliminates pediatric fluorosis for 18,500 villagers and saves 40 hours/week spent fetching water..."
                value={expectedImpact}
                onChange={(e) => setExpectedImpact(e.target.value)}
                className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
              ></textarea>
            </div>

            <div className="flex justify-between pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-5 py-2.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50"
              >
                &larr; Back
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!expectedImpact) {
                    showToast('warning', 'Expected Impact Required', 'Please specify the expected societal benefit.');
                    return;
                  }
                  setStep(3);
                }}
                className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                <span>Proceed to Evidence & Review</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5 animate-in fade-in duration-150">
            {/* Multimedia Evidence Uploader (Mock) */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-emerald-700" />
                  Multimedia Evidence & Supporting Documents
                </span>
                <span className="text-[10px] text-slate-500">Photos, Videos, Lab Reports, Gram Sabha resolution</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {evidenceList.map((ev, idx) => (
                  <div key={idx} className="p-3 bg-white rounded-xl border border-slate-200 flex items-center gap-3">
                    <img src={ev.url} alt="Evidence" className="w-14 h-14 rounded-lg object-cover border border-slate-200" />
                    <div className="flex-1 text-xs">
                      <span className="font-bold text-slate-800 block line-clamp-1">{ev.caption}</span>
                      <span className="text-[10px] text-slate-500 uppercase">{ev.type} &bull; Geotagged</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="text"
                  placeholder="Caption for additional photo/document..."
                  value={newCaption}
                  onChange={(e) => setNewCaption(e.target.value)}
                  className="flex-1 text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={handleAddSampleEvidence}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1 shrink-0"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Attach Evidence</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                Additional Information / Land Availability / Gram Sabha Endorsement
              </label>
              <textarea
                rows={2}
                placeholder="Mention if Gram Sabha has approved site or if electricity/water source is nearby..."
                value={additionalInformation}
                onChange={(e) => setAdditionalInformation(e.target.value)}
                className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
              ></textarea>
            </div>

            {/* Declaration Checkbox */}
            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={consentAccepted}
                  onChange={(e) => setConsentAccepted(e.target.checked)}
                  className="mt-0.5 w-4 h-4 text-emerald-700 rounded border-slate-300 focus:ring-emerald-500"
                />
                <span className="text-xs text-slate-700 leading-snug">
                  I hereby declare that this problem statement represents genuine community need in{' '}
                  <strong>{village}, {block}, {district}</strong>. I consent to Jharkhand Higher Education Institutions and Industry partners analyzing this data for research, prototyping, and solution deployment.
                </span>
              </label>
            </div>

            <div className="flex justify-between pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-5 py-2.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50"
              >
                &larr; Back
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-8 py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg hover:shadow-xl transition-all"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Running AI Triage & Registering...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Submit Challenge & Run AI Matching</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};
