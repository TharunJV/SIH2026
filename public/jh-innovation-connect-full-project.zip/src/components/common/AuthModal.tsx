import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { MOCK_USERS, JHARKHAND_DISTRICTS } from '../../mock/data';
import {
  X,
  UserCheck,
  Building2,
  GraduationCap,
  Briefcase,
  ShieldCheck,
  Sparkles,
  CheckCircle2,
  Users,
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, switchRole, currentUser, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'demo-login' | 'register'>('demo-login');

  // Register Form State
  const [regRole, setRegRole] = useState<UserRole>('citizen');
  const [regName, setRegName] = useState('');
  const [regOrg, setRegOrg] = useState('');
  const [regDistrict, setRegDistrict] = useState(JHARKHAND_DISTRICTS[0]);
  const [regEmail, setRegEmail] = useState('');

  if (!isAuthModalOpen) return null;

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail) {
      showToast('warning', 'Incomplete Form', 'Please enter your name and email.');
      return;
    }
    showToast('success', 'Registration Submitted', `Application for ${regName} (${regRole.toUpperCase()}) submitted to JSHEC PMU for instant prototype access.`);
    switchRole(regRole);
    setIsAuthModalOpen(false);
  };

  const roleCategories = [
    {
      title: 'Community & Grassroots',
      roles: ['citizen', 'pri_ulb', 'community_org'] as UserRole[],
      icon: Users,
      color: 'border-emerald-200 bg-emerald-50/50',
    },
    {
      title: 'Higher Education Institutions (HEIs)',
      roles: ['university_admin', 'faculty_mentor', 'student'] as UserRole[],
      icon: GraduationCap,
      color: 'border-blue-200 bg-blue-50/50',
    },
    {
      title: 'Industry & CSR Partners',
      roles: ['industry_msme', 'csr_org', 'research_institute'] as UserRole[],
      icon: Briefcase,
      color: 'border-purple-200 bg-purple-50/50',
    },
    {
      title: 'State Governance',
      roles: ['govt_department', 'platform_admin'] as UserRole[],
      icon: ShieldCheck,
      color: 'border-amber-200 bg-amber-50/50',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800 flex items-center justify-center text-amber-400 font-bold border border-emerald-600/30 text-sm">
              JH
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Stakeholder Access Portal</h3>
              <p className="text-xs text-slate-300">JH Innovation Connect &bull; Role-Based Experience</p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 sm:px-6 pt-3">
          <button
            onClick={() => setActiveTab('demo-login')}
            className={`pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'demo-login'
                ? 'border-emerald-700 text-emerald-900'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Instant Role Login (For Judges & Demo)</span>
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'register'
                ? 'border-emerald-700 text-emerald-900'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Register New Stakeholder</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {activeTab === 'demo-login' ? (
            <div className="space-y-5">
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Fast Hackathon Evaluation:</strong> Click any of the 11 pre-configured stakeholder profiles below to immediately load their tailored dashboard view, permissions, and workflow capabilities.
                </div>
              </div>

              <div className="space-y-4">
                {roleCategories.map((cat) => (
                  <div key={cat.title} className="space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
                      <cat.icon className="w-3.5 h-3.5 text-slate-500" />
                      <span>{cat.title}</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {cat.roles.map((r) => {
                        const matchedUser = MOCK_USERS.find((u) => u.role === r);
                        const isCurrent = currentUser.role === r;

                        return (
                          <button
                            key={r}
                            onClick={() => {
                              switchRole(r);
                              setIsAuthModalOpen(false);
                            }}
                            className={`p-2.5 rounded-xl border text-left transition-all relative ${
                              isCurrent
                                ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-500/20'
                                : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-bold capitalize text-slate-900">
                                {r.replace('_', ' ')}
                              </span>
                              {isCurrent && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              )}
                            </div>
                            <div className="text-[11px] text-slate-600 font-medium truncate mt-0.5">
                              {matchedUser?.name || 'Representative'}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate">
                              {matchedUser?.organization || matchedUser?.district}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Stakeholder Role</label>
                <select
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as UserRole)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="citizen">Citizen / Resident</option>
                  <option value="pri_ulb">Panchayati Raj Institution (PRI) / Urban Local Body</option>
                  <option value="community_org">Community Organization (NGO / SHG Federation)</option>
                  <option value="university_admin">University Administrator / Incubation Cell</option>
                  <option value="faculty_mentor">Faculty Mentor / Domain Professor</option>
                  <option value="student">Student Innovator / Research Scholar</option>
                  <option value="industry_msme">Industry / Startup / MSME</option>
                  <option value="csr_org">CSR Foundation / Philanthropic Trust</option>
                  <option value="research_institute">National Research Laboratory (CSIR/ICAR)</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Full Name / Representative Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Anil Kumar / Anita Soren"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Organization / Institution Name</label>
                  <input
                    type="text"
                    placeholder="e.g. BIT Mesra / Gram Panchayat Torpa"
                    value={regOrg}
                    onChange={(e) => setRegOrg(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="name@organization.ac.in"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Primary Jharkhand District</label>
                  <select
                    value={regDistrict}
                    onChange={(e) => setRegDistrict(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-emerald-500"
                  >
                    {JHARKHAND_DISTRICTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-[11px] text-slate-600">
                Institutional registrations are automatically vetted against Higher & Technical Education databases in Jharkhand.
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAuthModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-sm"
                >
                  Complete Registration & Login
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
