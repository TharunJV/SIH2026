import React from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
  GraduationCap,
  Briefcase,
  Users,
  Compass,
  CheckCircle2,
  TrendingUp,
  MapPin,
  HeartHandshake,
  Layers,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const {
    setCurrentView,
    switchRole,
    setIsAuthModalOpen,
    setIsDemoTourActive,
    goToDemoStep,
    challenges,
    navigateToChallenge,
  } = useApp();

  const roleFastCards: { role: UserRole; title: string; desc: string; icon: any; color: string }[] = [
    {
      role: 'citizen',
      title: 'Citizens & PRIs',
      desc: 'Submit local challenges with GPS geotagging & evidence.',
      icon: Users,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:border-emerald-500',
    },
    {
      role: 'university_admin',
      title: 'Higher Education (HEIs)',
      desc: 'Evaluate AI-matched challenges and build multidisciplinary student R&D teams.',
      icon: GraduationCap,
      color: 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:border-indigo-500',
    },
    {
      role: 'industry_msme',
      title: 'Industry & CSR',
      desc: 'Sponsor prototypes, provide testing facilities, and scale innovations.',
      icon: Briefcase,
      color: 'bg-purple-50 text-purple-800 border-purple-200 hover:border-purple-500',
    },
    {
      role: 'govt_department',
      title: 'State Governance',
      desc: 'Validate community problems and integrate proven pilots into state policy.',
      icon: ShieldCheck,
      color: 'bg-amber-50 text-amber-900 border-amber-200 hover:border-amber-500',
    },
  ];

  return (
    <div className="space-y-12 pb-8">
      {/* Sovereign Hero Section */}
      <section className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white p-8 sm:p-14 border border-emerald-500/30 shadow-2xl">
        {/* Decorative Grid Pattern */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Government of Jharkhand &bull; Smart India Hackathon 2026</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight text-white">
            Crowdsourcing Grassroots Challenges &bull; Solving via Universities & Industry
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl font-normal">
            A state-wide digital bridge connecting citizens facing water, agro, healthcare, and infrastructure obstacles with Jharkhand's premier Higher Education Institutions (BIT Mesra, IIT ISM, NIT) and CSR Industry Partners.
          </p>

          {/* Hero CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setCurrentView('submit-challenge')}
              className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg hover:shadow-emerald-600/30 transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Submit a Community Challenge</span>
            </button>

            <button
              onClick={() => {
                setIsDemoTourActive(true);
                goToDemoStep(1);
              }}
              className="px-6 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded-xl text-xs sm:text-sm font-bold shadow-lg transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-slate-950 fill-slate-950" />
              <span>Launch 3-Min Fast-Track Judge Tour</span>
            </button>
          </div>
        </div>

        {/* Live Counters Banner */}
        <div className="mt-10 pt-8 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 relative z-10">
          <div>
            <span className="text-2xl sm:text-3xl font-black text-amber-400 block">412+</span>
            <span className="text-xs text-slate-400">Crowdsourced Challenges</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 block">24 Districts</span>
            <span className="text-xs text-slate-400">100% Jharkhand Coverage</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-indigo-400 block">38 HEI Labs</span>
            <span className="text-xs text-slate-400">Multidisciplinary Cohorts</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-black text-teal-400 block">₹4.85 Cr</span>
            <span className="text-xs text-slate-400">CSR & State R&D Grants</span>
          </div>
        </div>
      </section>

      {/* Role-Based Portals */}
      <section className="space-y-4">
        <div className="text-center max-w-2xl mx-auto space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-800">
            Interactive Multi-Stakeholder Ecosystem
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Select Your Role to Experience the Platform
          </h2>
          <p className="text-xs text-slate-600">
            Test how each actor interacts across the entire problem-solving pipeline.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {roleFastCards.map((card) => (
            <div
              key={card.role}
              onClick={() => {
                switchRole(card.role);
                if (card.role === 'citizen') setCurrentView('citizen-dashboard');
                else if (card.role === 'university_admin') setCurrentView('university-dashboard');
                else if (card.role === 'industry_msme') setCurrentView('industry-dashboard');
                else if (card.role === 'govt_department') setCurrentView('government-dashboard');
              }}
              className={`p-6 rounded-2xl border ${card.color} cursor-pointer transition-all shadow-xs hover:shadow-md hover:scale-102 flex flex-col justify-between space-y-4`}
            >
              <div className="space-y-3">
                <card.icon className="w-8 h-8" />
                <h3 className="text-base font-bold text-slate-900">{card.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{card.desc}</p>
              </div>

              <div className="flex items-center gap-1 text-xs font-bold text-slate-900 pt-2">
                <span>Enter Role Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Community Challenges */}
      <section className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-800">
              Grassroots Ingestion
            </span>
            <h3 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
              Active Societal Challenges Seeking HEI Solutions
            </h3>
          </div>
          <button
            onClick={() => setCurrentView('explore-challenges')}
            className="px-4 py-2 border border-slate-300 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1 shrink-0"
          >
            <span>Explore All 24 Districts</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {challenges.slice(0, 3).map((ch) => (
            <div
              key={ch.id}
              onClick={() => navigateToChallenge(ch.id)}
              className="p-5 rounded-2xl border border-slate-200 hover:border-emerald-500 bg-slate-50/40 hover:bg-white cursor-pointer transition-all flex flex-col justify-between space-y-4 shadow-2xs"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {ch.id}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                      ch.urgency === 'Critical'
                        ? 'bg-rose-100 text-rose-800'
                        : ch.urgency === 'High'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {ch.urgency}
                  </span>
                </div>

                <h4 className="text-xs font-bold text-slate-900 leading-snug line-clamp-2">{ch.title}</h4>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{ch.description}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
                <span className="flex items-center gap-1 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-slate-600" />
                  {ch.district}
                </span>
                <span className="font-semibold text-emerald-800">{ch.status}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
