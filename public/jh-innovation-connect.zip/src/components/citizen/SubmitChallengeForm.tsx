import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ChallengeCategory, ChallengeUrgency } from '../../types';
import { JHARKHAND_DISTRICTS, CATEGORIES_LIST } from '../../mock/data';
import { challengeService } from '../../services/challengeService';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  MapPin,
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Camera,
  Video,
  ShieldCheck,
  ArrowRight,
  ChevronRight,
  Eye,
  Info,
  Clock,
  HelpCircle,
  Smile,
  FileSpreadsheet,
} from 'lucide-react';

export const SubmitChallengeForm: React.FC = () => {
  const { currentUser, showToast, refreshData, navigateToChallenge, setCurrentView } = useApp();

  // Submission Mode: 'simple' (Scenario B) vs 'detailed' (Scenario A)
  const [submissionMode, setSubmissionMode] = useState<'simple' | 'detailed'>('simple');
  const [step, setStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedChallengeId, setSubmittedChallengeId] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ChallengeCategory>('Water Resources');
  const [subCategory, setSubCategory] = useState('');
  const [district, setDistrict] = useState<string>('Khunti');
  const [block, setBlock] = useState('Torpa');
  const [village, setVillage] = useState('Dormo Panchayat');
  const [gps, setGps] = useState({ lat: 22.9567, lng: 85.0844 });
  const [affectedPopulation, setAffectedPopulation] = useState<number>(12500);
  const [frequency, setFrequency] = useState<'Daily' | 'Seasonal' | 'Recurring Periodic' | 'One-Time Event'>('Daily');
  const [urgency, setUrgency] = useState<ChallengeUrgency>('High');
  const [expectedImpact, setExpectedImpact] = useState('');
  const [additionalInformation, setAdditionalInformation] = useState('');
  const [consentAccepted, setConsentAccepted] = useState(true);

  // Quick Guided Mode Questions (Scenario B)
  const [simpleWhatHappened, setSimpleWhatHappened] = useState('');
  const [simpleWhoAffected, setSimpleWhoAffected] = useState('');

  // Mock Evidence Uploads
  const [evidenceList, setEvidenceList] = useState<
    { type: 'image' | 'video' | 'document' | 'audio'; url: string; caption: string }[]
  >([
    {
      type: 'image',
      url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?w=600&auto=format&fit=crop&q=80',
      caption: 'Groundwater pump crusting and turbidity',
    },
  ]);
  const [newCaption, setNewCaption] = useState('');

  const handleAutoGPS = () => {
    setGps({
      lat: Number((22.8 + Math.random() * 1.5).toFixed(4)),
      lng: Number((84.5 + Math.random() * 2.5).toFixed(4)),
    });
    showToast('info', 'GPS Coordinate Locked', `Geotagged location at ${gps.lat}° N, ${gps.lng}° E`);
  };

  const handleAddSampleEvidence = () => {
    setEvidenceList((prev) => [
      ...prev,
      {
        type: 'image',
        url: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=600&auto=format&fit=crop&q=80',
        caption: newCaption || 'Village community field evidence',
      },
    ]);
    setNewCaption('');
    showToast('success', 'Evidence Attached', 'Photo evidence uploaded to prototype storage bucket.');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // In simple mode, construct title and description from human answers
    let finalTitle = title;
    let finalDescription = description;
    let finalImpact = expectedImpact;

    if (submissionMode === 'simple') {
      if (!simpleWhatHappened.trim()) {
        showToast('warning', 'Missing Description', 'Please tell us what problem is happening in your area.');
        return;
      }
      finalDescription = simpleWhatHappened;
      finalTitle = finalTitle || `${district} - ${block}: Community Issue (${simpleWhatHappened.slice(0, 50)}...)`;
      finalImpact = finalImpact || `Relief for local residents of ${village || block} in ${district} facing this issue.`;
    } else {
      if (!finalTitle || !finalDescription) {
        showToast('warning', 'Missing Details', 'Please fill in the problem title and description.');
        return;
      }
      finalImpact = finalImpact || `Improve quality of life and access to essential resources for ${district} residents.`;
    }

    if (!consentAccepted) {
      showToast('warning', 'Confirmation Required', 'Please confirm that this represents a genuine community need.');
      return;
    }

    setIsSubmitting(true);
    try {
      const newCh = await challengeService.createChallenge({
        title: finalTitle,
        description: finalDescription,
        category: category || 'Water Resources',
        subCategory: subCategory || undefined,
        district: district || 'Ranchi',
        block: block || 'Sadar',
        village: village || 'Local Community',
        gpsCoordinates: gps,
        affectedPopulation: affectedPopulation || 1000,
        frequency: frequency || 'Daily',
        urgency: urgency || 'Medium',
        expectedImpact: finalImpact,
        additionalInformation: additionalInformation || (simpleWhoAffected ? `Affected Community Note: ${simpleWhoAffected}` : undefined),
        submittedBy: {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          contactNumber: currentUser.phone || '+91 98351 00000',
          organization: currentUser.organization,
        },
        evidenceUrls: evidenceList,
      });

      await refreshData();
      setSubmittedChallengeId(newCh.id);

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (err) {
        // Ignore in non-canvas environments
      }

      showToast('success', 'Problem Logged as Community Report', `Tracking ID: ${newCh.id}. Recorded in state portal.`);
    } catch (err) {
      showToast('error', 'Submission Error', 'Failed to register challenge.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // If submitted, show success state
  if (submittedChallengeId) {
    return (
      <div className="max-w-3xl mx-auto my-6 bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-2xl text-center space-y-6 animate-in zoom-in-95 duration-200">
        <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto ring-8 ring-emerald-50">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
            <span className="w-2 h-2 rounded-full bg-amber-600 animate-pulse"></span>
            <span>Recorded as: 🟡 Community Report</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Thank You for Bringing This to Light
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto leading-relaxed">
            Your report is logged into the JH Innovation Connect platform. State coordinators and university reviewers will now examine the issue and determine the best resolution pathway.
          </p>
        </div>

        {/* Challenge ID Box */}
        <div className="p-5 rounded-2xl bg-slate-900 text-white max-w-md mx-auto border border-slate-800 shadow-inner">
          <span className="text-[11px] text-slate-400 uppercase tracking-widest block font-bold">
            Your Unique Tracking ID
          </span>
          <div className="text-2xl font-black text-amber-400 tracking-wider my-1 font-mono">
            {submittedChallengeId}
          </div>
          <span className="text-[11px] text-slate-300 flex items-center justify-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            Next Step: Authority Review & Investigation
          </span>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-left max-w-lg mx-auto text-xs text-slate-600 space-y-2">
          <div className="font-bold text-slate-900 flex items-center gap-1.5">
            <Info className="w-4 h-4 text-emerald-700" />
            <span>What happens next?</span>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            1. <strong>Verification:</strong> Local authorities review the report and evidence.
            <br />
            2. <strong>Routing:</strong> If it is a maintenance matter, it goes to the line department. If it requires technical innovation, it goes to university labs (BIT Mesra / IIT ISM).
            <br />
            3. <strong>Updates:</strong> You will be able to follow progress directly through your tracking ID.
          </p>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => navigateToChallenge(submittedChallengeId)}
            className="w-full sm:w-auto px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Track Challenge Journey &rarr;</span>
          </button>
          <button
            onClick={() => {
              setSubmittedChallengeId(null);
              setTitle('');
              setDescription('');
              setSimpleWhatHappened('');
              setStep(1);
            }}
            className="w-full sm:w-auto px-5 py-3 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-all"
          >
            Submit Another Problem
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Friendly Human Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
              Grassroots Problem Ingestion
            </span>
            <span className="text-xs text-slate-400">SIH Problem Statement 26043</span>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs">
            <button
              type="button"
              onClick={() => setSubmissionMode('simple')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                submissionMode === 'simple'
                  ? 'bg-emerald-700 text-white shadow-2xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smile className="w-3.5 h-3.5" />
              <span>Need Help Explaining? (Simple Mode)</span>
            </button>
            <button
              type="button"
              onClick={() => setSubmissionMode('detailed')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                submissionMode === 'detailed'
                  ? 'bg-emerald-700 text-white shadow-2xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Detailed Submission</span>
            </button>
          </div>
        </div>

        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          {submissionMode === 'simple' ? 'Tell Us About a Problem in Your Area' : 'Structured Challenge Submission Form'}
        </h1>

        <div className="p-3 bg-emerald-950/60 border border-emerald-500/30 rounded-xl text-xs text-emerald-200 flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>You do not need to know how to solve the problem or write technical terms.</strong> You just need to help us understand what is happening. The platform, state coordinators, and university researchers will structure and investigate it.
          </p>
        </div>
      </div>

      {/* SCENARIO B: QUICK & SIMPLE GUIDED MODE */}
      {submissionMode === 'simple' ? (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Smile className="w-4 h-4 text-emerald-700" />
              Step 1 of 1: Simple Community Description
            </span>
            <span className="text-[11px] text-slate-500">Only 2 questions strictly required</span>
          </div>

          {/* Question 1: What is happening? (REQUIRED) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-900">
              1. What is the problem you or your community are facing? <span className="text-rose-600 font-extrabold">(Required)</span>
            </label>
            <p className="text-[11px] text-slate-500">
              Describe in plain words what happens, when it started, or how it affects everyday life.
            </p>
            <textarea
              rows={4}
              required
              placeholder="Example: In our village, handpumps have high yellowish sediment during summer and children complain of stomach aches. Or: We have good lac harvest but no local drying or processing facility so half the produce spoils..."
              value={simpleWhatHappened}
              onChange={(e) => setSimpleWhatHappened(e.target.value)}
              className="w-full text-xs sm:text-sm p-3.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 leading-relaxed"
            ></textarea>
          </div>

          {/* Question 2: Where is it happening? (REQUIRED) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-900">
              2. Where is this problem located? <span className="text-rose-600 font-extrabold">(Required)</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <span className="text-[11px] text-slate-600 font-semibold block mb-1">District</span>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 font-bold focus:ring-2 focus:ring-emerald-500"
                >
                  {JHARKHAND_DISTRICTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <span className="text-[11px] text-slate-600 font-semibold block mb-1">Block / Town</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Torpa / Katras / Sadar"
                  value={block}
                  onChange={(e) => setBlock(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <span className="text-[11px] text-slate-600 font-semibold block mb-1">Village / Ward (Optional)</span>
                <input
                  type="text"
                  placeholder="e.g. Dormo Panchayat"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Question 3: Who is affected? (OPTIONAL) */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-900">
              3. Who is affected? <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              placeholder="e.g., Around 200 farming families, school children, whole panchayat..."
              value={simpleWhoAffected}
              onChange={(e) => setSimpleWhoAffected(e.target.value)}
              className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Question 4: Photos or evidence? (OPTIONAL) */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-emerald-700" />
                <span>4. Photos or Documents <span className="text-slate-400 font-normal">(Optional)</span></span>
              </label>
              <span className="text-[10px] text-slate-400">Can be uploaded now or later</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {evidenceList.map((ev, idx) => (
                <div key={idx} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-3">
                  <img src={ev.url} alt="Evidence" className="w-12 h-12 rounded-lg object-cover border border-slate-200" />
                  <div className="flex-1 text-xs">
                    <span className="font-semibold text-slate-800 block line-clamp-1">{ev.caption}</span>
                    <span className="text-[10px] text-emerald-700 font-bold uppercase">Attached Photo</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                placeholder="Caption for photo/document..."
                value={newCaption}
                onChange={(e) => setNewCaption(e.target.value)}
                className="flex-1 text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={handleAddSampleEvidence}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1 shrink-0"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Add Photo</span>
              </button>
            </div>
          </div>

          {/* Friendly Guidance Box */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
            <p className="leading-relaxed text-[11px]">
              <strong>Missing details?</strong> No problem! If anything is unclear, our coordinators will get in touch to help gather additional details rather than rejecting a genuine community need.
            </p>
          </div>

          {/* Declaration Checkbox */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={consentAccepted}
                onChange={(e) => setConsentAccepted(e.target.checked)}
                className="mt-0.5 w-4 h-4 text-emerald-700 rounded border-slate-300 focus:ring-emerald-500"
              />
              <span className="text-xs text-slate-700 leading-snug">
                I confirm that this is a genuine community observation in <strong>{district}</strong>. I consent to review by Jharkhand State Higher Education authorities and institutional researchers.
              </span>
            </label>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto px-8 py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
            >
              {isSubmitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Registering Community Report...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Submit Community Report</span>
                </>
              )}
            </button>
          </div>
        </form>
      ) : (
        /* SCENARIO A: DETAILED 3-STEP WIZARD */
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Detailed Challenge Submission
              </span>
              <span className="text-xs text-slate-400">&bull; Step {step} of 3</span>
            </div>
            <div className="flex items-center gap-1 text-xs">
              <button
                type="button"
                onClick={() => setStep(1)}
                className={`px-2.5 py-1 rounded font-bold ${step === 1 ? 'bg-emerald-700 text-white' : 'text-slate-500'}`}
              >
                1. Problem
              </button>
              <button
                type="button"
                onClick={() => setStep(2)}
                className={`px-2.5 py-1 rounded font-bold ${step === 2 ? 'bg-emerald-700 text-white' : 'text-slate-500'}`}
              >
                2. Location & Impact
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className={`px-2.5 py-1 rounded font-bold ${step === 3 ? 'bg-emerald-700 text-white' : 'text-slate-500'}`}
              >
                3. Evidence & Review
              </button>
            </div>
          </div>

          {step === 1 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Challenge Title <span className="text-rose-600 font-bold">(Required)</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., High Fluoride Contamination in Handpumps of Torpa Block"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs sm:text-sm p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  A concise summary stating the primary grassroots obstacle.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Primary Domain / Category <span className="text-slate-400 font-normal">(Optional - can be auto-categorized)</span>
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ChallengeCategory)}
                    className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    {CATEGORIES_LIST.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Sub-Category / Technical Focus <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Groundwater Purification & IoT Telemetry"
                    value={subCategory}
                    onChange={(e) => setSubCategory(e.target.value)}
                    className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Comprehensive Problem Description <span className="text-rose-600 font-bold">(Required)</span>
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder="Describe what is happening, what causes the issue, who is suffering, seasonal variations, and past failed remedies..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 leading-relaxed"
                ></textarea>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (!title || !description) {
                      showToast('warning', 'Required Fields', 'Please enter title and description.');
                      return;
                    }
                    setStep(2);
                  }}
                  className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <span>Proceed to Location & Impact</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    District <span className="text-rose-600 font-bold">(Required)</span>
                  </label>
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    {JHARKHAND_DISTRICTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Block / Tehsil <span className="text-rose-600 font-bold">(Required)</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Torpa / Bishunpur / Katras"
                    value={block}
                    onChange={(e) => setBlock(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Village / Ward / Locality <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Dormo & Jamhar Tolas"
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* GPS Geotagging Box */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">GPS Coordinates (Optional Geotag)</span>
                    <span className="text-[11px] text-slate-600 font-mono">
                      Lat: {gps.lat.toFixed(4)}° N, Lng: {gps.lng.toFixed(4)}° E &bull; Accuracy: ±3m
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleAutoGPS}
                  className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-100 shadow-2xs"
                >
                  Refresh Device GPS
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Estimated Affected People <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="number"
                    min={10}
                    value={affectedPopulation}
                    onChange={(e) => setAffectedPopulation(Number(e.target.value))}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Frequency <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as any)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Daily">Daily / Constant</option>
                    <option value="Seasonal">Seasonal (Monsoon / Summer)</option>
                    <option value="Recurring Periodic">Recurring Periodic</option>
                    <option value="One-Time Event">One-Time Event</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-900 mb-1">
                    Urgency Assessment <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <select
                    value={urgency}
                    onChange={(e) => setUrgency(e.target.value as ChallengeUrgency)}
                    className="w-full text-xs p-2.5 border border-slate-300 rounded-xl bg-slate-50 font-bold focus:ring-2 focus:ring-emerald-500 text-amber-900"
                  >
                    <option value="Critical">Critical (Immediate Health/Life Risk)</option>
                    <option value="High">High (Severe Economic/Livelihood Loss)</option>
                    <option value="Medium">Medium (Regular Inconvenience)</option>
                    <option value="Low">Low (General Quality of Life)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Expected Benefit / Impact of Solution <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="What will improve once solved? e.g. Eliminates fluorosis for villagers and saves hours fetching water..."
                  value={expectedImpact}
                  onChange={(e) => setExpectedImpact(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                ></textarea>
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-5 py-2.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  &larr; Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <span>Proceed to Evidence & Review</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* Multimedia Evidence Uploader */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-emerald-700" />
                    Multimedia Evidence & Supporting Documents <span className="text-slate-400 font-normal text-[11px]">(Optional)</span>
                  </span>
                  <span className="text-[10px] text-slate-500">Photos, Videos, Lab Reports, Gram Sabha notes</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {evidenceList.map((ev, idx) => (
                    <div key={idx} className="p-3 bg-white rounded-xl border border-slate-200 flex items-center gap-3">
                      <img src={ev.url} alt="Evidence" className="w-14 h-14 rounded-lg object-cover border border-slate-200" />
                      <div className="flex-1 text-xs">
                        <span className="font-bold text-slate-800 block line-clamp-1">{ev.caption}</span>
                        <span className="text-[10px] text-slate-500 uppercase">{ev.type} &bull; Geotagged</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="text"
                    placeholder="Caption for additional photo/document..."
                    value={newCaption}
                    onChange={(e) => setNewCaption(e.target.value)}
                    className="flex-1 text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddSampleEvidence}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1 shrink-0"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Attach Evidence</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Additional Information / Gram Sabha Endorsement <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="Mention if Gram Sabha has discussed site or if electricity/water source is nearby..."
                  value={additionalInformation}
                  onChange={(e) => setAdditionalInformation(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                ></textarea>
              </div>

              {/* Declaration Checkbox */}
              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
                <label className="flex items-start gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={consentAccepted}
                    onChange={(e) => setConsentAccepted(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-700 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  <span className="text-xs text-slate-700 leading-snug">
                    I declare that this problem statement represents a genuine community need in{' '}
                    <strong>{village || block}, {district}</strong>. I consent to review by Jharkhand Higher Education Institutions and Industry partners.
                  </span>
                </label>
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-5 py-2.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  &larr; Back
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-8 py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg hover:shadow-xl transition-all"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      <span>Registering Community Report...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Submit Challenge & Run AI Triage</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </form>
      )}
    </div>
  );
};

